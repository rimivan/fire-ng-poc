import {Component, OnInit} from '@angular/core';
import {AngularFirestore, AngularFirestoreModule} from '@angular/fire/firestore';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(private db: AngularFireDatabase) {
  }
  ngOnInit(): void {
    const root = this.db.database.ref();
    root.on('value', (snap) => {
      console.log(snap.val());
    });
  }
}
